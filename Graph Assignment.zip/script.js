// (x, y , width, height)
const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");
/*context.beginPath();
context.rect(20, 20, 150, 100);
context.stroke();*/
let barValues = [];
const defaultColors = [
  "ffffff",
  "55415f",
  "646964",
  "d77355",
  "508cd7",
  "64b964",
  "e6c86e",
  "dcf5ff",
];
let currentColors = defaultColors;
const render = () => {
  let bars = document.querySelectorAll(".bar-height-slider");
  let numOfBars = document.getElementById("quantity").value;
  let maxWidth = document.getElementById("max-width-slider").value / 100;
  let indivWidth = document.getElementById("indiv-width-slider").value / 100;
  let maxHeight =
    (canvas.height * (document.getElementById("height-slider").value / 100)) /
    100;
  // console.log({ maxHeight });
  const canWidth = canvas.width * maxWidth;
  let lastAdd = 0;
  let sliderCount = document.querySelectorAll(".bar-height-slider").length;
  const generateSlider = (num) => {
    num++;
    num += sliderCount;
    console.log({ sliderCount });
    const slider = document.getElementById("chart-slider-area");
    slider.innerHTML += `<div><label>Value ${num} </label><input type="range" min="0" max="100" value="50" class="bar-height-slider" id='${num}'><span>1</span></div>`;
  };
  bars = document.querySelectorAll(".bar-height-slider");
  barValues = [];
  bars.forEach((element) => {
    barValues.push(element.value);
  });
  let currentSliders = document.getElementById("chart-slider-area").children
    .length;
  if (currentSliders < numOfBars) {
    const add = numOfBars - currentSliders;
    for (let i = 0; i < add; i++) {
      //let slider = document.getElementById("chart-slider-area");
      /*let newElement = document.createElement("input");
      newElement.setAttribute("type", "range");
      newElement.setAttribute("min", "0");
      newElement.setAttribute("max", "100");
      newElement.setAttribute("value", "50");
      newElement.setAttribute("class", "bar-height-slider");
      slider.appendChild(newElement); */
      // slider.innerHTML +=
      // '<input type="range" min="0" max="100" value="50" class="bar-height-slider">'
      lastAdd = add;
      generateSlider(i);
    }
  } else if (currentSliders > numOfBars) {
    const sub = currentSliders - numOfBars;
    let child = document.getElementById("chart-slider-area").children;
    //console.log(child);
    for (let i = sub; i > 0; i--) {
      // console.log(i);
      //barValues.pop();
      child[i].parentNode.removeChild(child[i]);
      sliderCount = 0;
      //console.log({barValues})
      //barValues.forEach(element => {element = 50;})
      //  console.log({barValues})
    }
    let slider = document.getElementById("chart-slider-area");
    slider.innerHTML = "";
    for (let i = 0; i < numOfBars; i++) {
      generateSlider(i);
      //slider.innerHTML +=
      //'<input type="range" min="0" max="100" value="50" class="bar-height-slider">';
    }
  }
  bars = document.querySelectorAll(".bar-height-slider");
  barValues = [];
  bars.forEach((element) => {
    barValues.push(element.value);
  });
  console.log({ bars });
  console.log("%cBackground", `background-color: #${currentColors[7]};`)
  context.fillStyle = "#" + currentColors[7];
  context.fillRect(0, 0, canvas.width, canvas.height);
  console.log({ barValues });
  for (let i = 0; i < numOfBars; i++) {
    const heighOfRect = barValues[i] * maxHeight;
    const barArea = canWidth / numOfBars;
    const barWidth = barArea * indivWidth;
    const centerCorrect = (barArea - barWidth) / 2;
    const startX = (canWidth / numOfBars) * i + centerCorrect;
    const startY = canvas.height - heighOfRect;
    //  console.log({maxHeight})
    context.beginPath();
    context.rect(
      startX, //Starting point X
      startY, //Starting point Y
      barWidth, //Width
      heighOfRect //Height
    );
    context.fillStyle = "#" + currentColors[i];
    context.fill();
    context.stroke();
    const test = i + 1;

    document.getElementById(test).nextSibling.innerHTML =
      document.getElementById(test).value + "%";
  }
  document.getElementById("height-slider").nextElementSibling.innerHTML =
    document.getElementById("height-slider").value + "%";
  document.getElementById("max-width-slider").nextElementSibling.innerHTML =
    document.getElementById("max-width-slider").value + "%";
  document.getElementById("indiv-width-slider").nextElementSibling.innerHTML =
    document.getElementById("indiv-width-slider").value + "%";
};

  function getData() {
    /* Call function to commence JSONP request 
  
  URL consistes of
  
  1 - nr of colour schemes you want
  2 - scheme_size_limit=>5 - This limits the nr of colours to 5 or more (may not work perfectly)
  3 - callback=processColorData  -- specify the callback function
  
  */

    send_JSONP_Request(
      "http://www.colr.org/json/schemes/random/5?scheme_size_limit=>5&callback=processColorData"
    );

      document.getElementById('new-colour').innerHTML = 'loading...'
      document.getElementById('new-colour').style.opacity = 0.5;
render();
  }

  function processColorData(data) {
    // The following will output the contents of the data object in the console
    // for debugging purposes only
    console.log(data);

    // check if there are 0 schemes or less than 5 colours
    if (data.schemes.length == 0 || data.schemes[1].colors.length < 7) {
      alert('error')
      currentColors =[]
      currentColors = data.schemes[Math.floor(Math.random()*7)].colors;
      console.log({currentColors});
    } else {
      // Get the array of colours from the JSON object
      // We only need the first scheme (at index 0)
      console.log({currentColors});
      currentColors = data.schemes[1].colors;
      console.log({currentColors});
      render();
      var randomColours = data.schemes[0].colors;

      // Change the color of the <div> elements (and <body>) making up the page
      // Place the hex code of the colour as text in the appropriate <div>
    }

    document.getElementById('new-colour').innerHTML = 'New Colours'
      document.getElementById('new-colour').style.opacity = 1;
  }

  // Make a JSONP request with the supplied URL
  function send_JSONP_Request(request) {
    const head = document.getElementsByTagName("head")[0]

    if(document.getElementsByTagName('SCRIPT').length > 2){
      alert('ech')
       head.removeChild(head.lastElementChild)
     }
    newScript = document.createElement("script");
    newScript.setAttribute("src", request);
    document.getElementsByTagName("head")[0].appendChild(newScript);
    render();
  }

  const resetColour = () => {
    currentColors = defaultColors;
    render();
  }



const init = () => {
  document.getElementById("page").addEventListener("keypress", render);
  document.getElementById("page").addEventListener("click", render);

  document.getElementById("new-colour").addEventListener("click", getData);
  document.getElementById('reset-colour').addEventListener("click", resetColour)
  render();
};
init();
